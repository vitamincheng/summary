.. the Summary of vitamin's labs documentation master file, created by
   sphinx-quickstart on Thu Dec 15 11:04:45 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the Summary of Vitamin's labs documentation!
===============================================================

| 
| The Summary focuses on the DoE and QbD data from 2000 to now (main Journal OPR&D) after 15 years pharmaceuticl industry.
| Others information like structure elucidation from quantum mechanical method xtb or orca will be prepared in furture. 


.. toctree::
   :maxdepth: 2
   :caption: Table of Contents

   CH1/index
   CH2/index
   CH3/index
   CH4/index
   About


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
