.. the Summary of vitamin's labs documentation master file, created by
   sphinx-quickstart on Thu Dec 15 11:04:45 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Pharmaceutical Industry
===============================================================

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents 1. Pharmaceutical Industry 

   Section1
   Section2
   Section3
   Section5
